package gr.hua.ergasia.ds_ergasia_2024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsErgasia2024ApplicationTests {

	@Test
	void contextLoads() {
	}

}
