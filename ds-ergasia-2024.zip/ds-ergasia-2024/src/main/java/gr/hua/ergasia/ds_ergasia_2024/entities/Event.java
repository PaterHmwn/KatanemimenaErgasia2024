package gr.hua.ergasia.ds_ergasia_2024.entities;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity  // Η κλάση αυτή αντιστοιχεί σε πίνακα στην βάση δεδομένων
public class Event {

    // Δηλώνει το πρωτεύον κλειδί για αυτήν την οντότητα
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Η τιμή του ID θα δημιουργείται αυτόματα από την βάση
    private Long id;

    private String title;  // Τίτλος της εκδήλωσης
    private String description;  // Περιγραφή της εκδήλωσης
    private LocalDateTime eventDate;  // Ημερομηνία και ώρα της εκδήλωσης
    private boolean approved;  // Αν η εκδήλωση έχει εγκριθεί από τον Admin

    @ManyToOne  // Σχέση many-to-one με την οργάνωση που δημοσιεύει την εκδήλωση
    private Organization organization;  // Η οργάνωση που δημοσιεύει την εκδήλωση

    // Getters and Setters
    // Μέθοδοι για να διαβάσουμε και να τροποποιήσουμε τα πεδία αυτής της οντότητας

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getEventDate() {
        return eventDate;
    }

    public void setEventDate(LocalDateTime eventDate) {
        this.eventDate = eventDate;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    public Organization getOrganization() {
        return organization;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }
}
